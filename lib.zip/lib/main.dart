import 'package:distributed_computing_project/pages/sessions_display_page.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const SessionsDisplayPage());
}